Boundary First Flattening v1.1 (January 2019)

authors: Rohan Sawhney and Keenan Crane

For more information see http://geometry.cs.cmu.edu/bff