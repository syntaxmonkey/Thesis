#!/bin/bash
cd "${0%/*}"
./bff-viewer face.obj
