#include "Bff.h"
#include "MeshIO.h"
#include "HoleFiller.h"
#include "Generators.h"
#include "ConePlacement.h"
#include "Cutter.h"
#include <math.h>

using namespace bff;

void printUsage(const std::string& programName)
{
	std::cout << "USAGE: "
			  << programName
			  << " OBJ_INPUT_PATH "
			  << "OBJ_OUTPUT_PATH "
			  << "[--nCones=N_CONES] "
			  << "[--flattenToDisk] "
			  << "[--mapToSphere] "
			  << "[--normalizeUVs]"
			  << std::endl;
}

bool doesArgExist(const std::string& arg, const std::string& searchStr)
{
	return arg.find(searchStr) != std::string::npos;
}

bool parseArg(const std::string& arg, const std::string& searchStr, std::string& value)
{
	if (doesArgExist(arg, searchStr)) {
		value = arg.substr(arg.find_first_of(searchStr[searchStr.size()-1]) + 1);
		return true;
	}

	return false;
}

void parseArgs(int argc, const char *argv[], std::string& inputPath, std::string& outputPath,
		   	   int& nCones, bool& flattenToDisk, bool& mapToSphere, bool& normalizeUVs, float& angle)
{
	if (argc < 3) {
		// input and/or output path not specified
		printUsage(argv[0]);
		exit(EXIT_FAILURE);

	} else {
		// parse arguments
		inputPath = argv[1];
		outputPath = argv[2];
		std::string nConesStr;
        std::string angleStr;

		for (int i = 3; i < argc; i++) {
			if (parseArg(argv[i], "--nCones=", nConesStr)) nCones = std::stoi(nConesStr);
			if (parseArg(argv[i], "--angle=", angleStr)) angle = std::stof(angleStr);
            if (doesArgExist(argv[i], "--flattenToDisk")) flattenToDisk = true;
			if (doesArgExist(argv[i], "--mapToSphere")) mapToSphere = true;
			if (doesArgExist(argv[i], "--normalizeUVs")) normalizeUVs = true;
		}
	}

	// if cones are specified, set flattenToDisk and mapToSphere to false
	if (nCones > 0) {
		flattenToDisk = false;
		mapToSphere = false;
	}
}

void loadModel(const std::string& inputPath, std::vector<Mesh>& model,
			   std::vector<bool>& surfaceIsClosed)
{
	std::string error;
	if (MeshIO::read(inputPath, model, error)) {
		int nMeshes = (int)model.size();
		surfaceIsClosed.resize(nMeshes, false);

		for (int i = 0; i < nMeshes; i++) {
			Mesh& mesh = model[i];
			int nBoundaries = (int)mesh.boundaries.size();

			if (nBoundaries >= 1) {
				// mesh has boundaries
				int eulerPlusBoundaries = mesh.eulerCharacteristic() + nBoundaries;

				if (eulerPlusBoundaries == 2) {
					// fill holes if mesh has more than 1 boundary
					if (nBoundaries > 1) {
						if (HoleFiller::fill(mesh)) {
							// all holes were filled
							surfaceIsClosed[i] = true;
						}
					}

				} else {
					// mesh probably has holes and handles
					HoleFiller::fill(mesh, true);
					Generators::compute(mesh);
				}

			} else if (nBoundaries == 0) {
				if (mesh.eulerCharacteristic() == 2) {
					// mesh is closed
					surfaceIsClosed[i] = true;

				} else {
					// mesh has handles
					Generators::compute(mesh);
				}
			}
		}

	} else {
		std::cerr << "Unable to load file: " << inputPath << ". " << error << std::endl;
		exit(EXIT_FAILURE);
	}
}

std::string& ltrim(std::string& str, const std::string& chars = "\t\n\v\f\r ")
{
    str.erase(0, str.find_first_not_of(chars));
    return str;
}
 
std::string& rtrim(std::string& str, const std::string& chars = "\t\n\v\f\r ")
{
    str.erase(str.find_last_not_of(chars) + 1);
    return str;
}
 
std::string& trim(std::string& str, const std::string& chars = "\t\n\v\f\r ")
{
    return ltrim(rtrim(str, chars), chars);
}


void flatten(std::vector<Mesh>& model, const std::vector<bool>& surfaceIsClosed,
			 int nCones, bool flattenToDisk, bool mapToSphere, float angle)
{
	int nMeshes = (int)model.size();
	for (int i = 0; i < nMeshes; i++) {
		Mesh& mesh = model[i];
		BFF bff(mesh);

		if (nCones > 0) {
			std::vector<VertexIter> cones;
			DenseMatrix coneAngles(bff.data->iN);
            
			ConePlacement::findConesAndPrescribeAngles(nCones, cones, coneAngles, bff.data, mesh);
			Cutter::cut(cones, mesh);
			bff.flattenWithCones(coneAngles, true);

		} else {
			if (surfaceIsClosed[i]) {
				if (mapToSphere) {
					bff.mapToSphere();

				} else {
					std::cerr << "Surface is closed. Either specify nCones or mapToSphere." << std::endl;
					exit(EXIT_FAILURE);
				}

			} else {
				if (flattenToDisk) {
					bff.flattenToDisk();

				} else {
                    
                    DenseMatrix u(bff.data->bN);
                    if (angle > 0) {
                        
                        float circleAngle=360;
                        float eachAngle = angle;
                        int cornerIndex = floor(bff.data->bN / 4);
                        int startNotchIndex = floor(cornerIndex / 4);
                        int notchLength = floor(cornerIndex /8)+1;
                        
                        /****
                        
                        for (int i=0; i< bff.data->bN ; i++) {
                            float currentAngle =eachAngle*i/bff.data->bN;
                            if  (circleAngle - currentAngle > 0) {
                                u(i) = eachAngle*(i%4 - 2); // - Produces semi jagged circle.
                                //u(i) = currentAngle; // Should produce spiral.
                                std::cout << "Angle " << currentAngle << "\n";
                                circleAngle=circleAngle-currentAngle;
                            } else {
                                u(i) = 0;
                            }
                        }
                        */

                        
                        /* This code reads in chaincode with angles. */
                        std::string inputFile = "chaincode.txt";
                        std::ifstream file(inputFile); // Read in a file: https://stackoverflow.com/questions/13035674/how-to-read-line-by-line-or-a-whole-text-file-at-once
                        std::string str;
                        std::string::size_type sz;

                        for (int i=0; i< bff.data->bN - 1 ; i++) {
                            std::getline(file, str);
                            
                            //float currentAngle =eachAngle*i/bff.data->bN;
                            trim(str);  // Trim string: http://www.martinbroadhurst.com/how-to-trim-a-stdstring.html
                            std::cout << "Angle string: " << str << "\n";
                            float currentAngle = std::stof (str); // Convert to float: http://www.cplusplus.com/reference/string/stof/
                                                            
                            if  (currentAngle != 0) {
                                u(i) = 3.1415/180 * currentAngle;
                            } else {
                                u(i) = 0;
                            }
                        }
                                                
                        file.close();
                        
                        
                        /** This code creates a square with a notch. */
                        /*
                        for (int i=0; i< bff.data->bN - 1 ; i++) {
                            float currentAngle =eachAngle*i/bff.data->bN;
                            if  (circleAngle - currentAngle > 0) {
                                if (i%cornerIndex==0) {
                                    u(i) = 3.1415/2; // - Produces semi jagged circle.
                                    //u(i) = currentAngle; // Should produce spiral.
                                    std::cout << "Square corner " << currentAngle << "\n";
                                    //circleAngle=circleAngle-currentAngle;
                                    
                                    // The ELSE IF statements create the notch in the image.
                                    //
                                } else if(i==startNotchIndex ) {
                                    u(i) = 3.1415/2; // Rotate clockwise by 90 degrees.
                                } else if(i==startNotchIndex+notchLength) {
                                    u(i) = -3.1415/2; // Rotate counter-clockwise by 90 degrees.
                                } else if(i==startNotchIndex+notchLength*2) {
                                    u(i) = -3.1415/2; // Rotate counter-clockwise by 90 degrees.
                                } else if(i==startNotchIndex+notchLength*3) {
                                    u(i) = 3.1415/2; // Rotate clockwise by 90 degrees.
                                }
                                
                            } else {
                                u(i) = 0;
                            }
                        }
                         */
                        
                        //u(bff.data->bN - 1) = eachAngle;
                        bff.flatten(u, false);
                        //****
                        
                    } else {
                        std::cout << "Angle is Zero\n";
                        bff.flatten(u, true);
                    }
                    std::cout << "Boundary count: " << bff.data->bN;
                    //DenseMatrix u(2); // Number of boundaries.
					//bff.flatten(u, true);
                    //bff.flatten(u,true);
				}
			}
		}
	}
}

void writeModelUVs(const std::string& outputPath, std::vector<Mesh>& model,
				   const std::vector<bool>& surfaceIsClosed, bool mapToSphere,
				   bool normalizeUVs)
{
	int nMeshes = (int)model.size();
	std::vector<bool> mappedToSphere(nMeshes, false);
	for (int i = 0; i < nMeshes; i++) {
		if (surfaceIsClosed[i]) {
			mappedToSphere[i] = mapToSphere;
		}
	}

	if (!MeshIO::write(outputPath, model, mappedToSphere, normalizeUVs)) {
		std::cerr << "Unable to write file: " << outputPath << std::endl;
		exit(EXIT_FAILURE);
	}
}

int main(int argc, const char *argv[]) {
	// parse command line options
	std::string inputPath = "";
	std::string outputPath = "";
	int nCones = 0;
	bool flattenToDisk = false;
	bool mapToSphere = false;
	bool normalizeUVs = false;
    float angle = 0;
	parseArgs(argc, argv, inputPath, outputPath, nCones,
			  flattenToDisk, mapToSphere, normalizeUVs, angle);

	// load model
	std::vector<Mesh> model;
	std::vector<bool> surfaceIsClosed;
	loadModel(inputPath, model, surfaceIsClosed);

	// set nCones to 8 for closed surfaces`
	for (int i = 0; i < (int)model.size(); i++) {
		if (surfaceIsClosed[i] && !mapToSphere && nCones < 3) {
			std::cout << "Setting nCones to 8." << std::endl;
			nCones = 8;
		}
	}

	// flatten
	flatten(model, surfaceIsClosed, nCones, flattenToDisk, mapToSphere, angle);

	// write model uvs to output path
	writeModelUVs(outputPath, model, surfaceIsClosed, mapToSphere, normalizeUVs);

	return 0;
}
